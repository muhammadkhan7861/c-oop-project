#include <iostream>
using namespace std;

class Person {
protected:
    string name;
    int age;
public:
    Person(string n = "", int a = 0) : name(n), age(a) {}
    virtual void showInfo() const = 0;
};

class Doctor : public Person {
private:
    string specialization;
public:
    Doctor(string n = "", int a = 0, string spec = "")
        : Person(n, a), specialization(spec) {}

    string getName() const { return name; }

    void showInfo() const override {
        cout << "Doctor: " << name
             << " | Age: " << age
             << " | Specialization: " << specialization << endl;
    }
};

class Patient : public Person {
private:
    string disease;
    string doctorName;
public:
    Patient(string n = "", int a = 0, string dis = "", string doc = "")
        : Person(n, a), disease(dis), doctorName(doc) {}

    void showInfo() const override {
        cout << "Patient: " << name
             << " | Age: " << age
             << " | Disease: " << disease
             << " | Doctor: " << doctorName << endl;
    }

    bool isEmpty() const { return name == ""; }
    string getName() const { return name; }
    void clear() { name = ""; age = 0; disease = ""; doctorName = ""; }
};

void hospitalIntro() {
    cout << "\n========================================\n";
    cout << "        WELCOME TO CITY HOSPITAL\n";
    cout << "========================================\n";
    cout << "We have 2 doctors available.\n";
    cout << "This demo allows maximum 2 patients.\n";
    cout << "----------------------------------------\n";
}

void showDoctors(Doctor &d1, Doctor &d2) {
    cout << "\n--- Doctors Available ---\n";
    cout << "1. "; d1.showInfo();
    cout << "2. "; d2.showInfo();
}

void admitPatient(Patient &p1, Patient &p2, int &patientCount, Doctor &d1, Doctor &d2) {
    if (patientCount >= 2) {
        cout << "? Sorry, hospital is full!\n";
        return;
    }

    string pname, disease;
    int age, choice;

    cout << "\nEnter Patient Name: ";
    cin >> pname;
    cout << "Enter Age: ";
    cin >> age;
    cout << "Enter Disease: ";
    cin >> disease;

    showDoctors(d1, d2);
    cout << "Choose Doctor (1 or 2): ";
    cin >> choice;

    if (choice == 1) {
        if (patientCount == 0)
            p1 = Patient(pname, age, disease, d1.getName());
        else
            p2 = Patient(pname, age, disease, d1.getName());

        patientCount++;
        cout << "? Patient admitted under " << d1.getName() << endl;
    }
    else if (choice == 2) {
        if (patientCount == 0)
            p1 = Patient(pname, age, disease, d2.getName());
        else
            p2 = Patient(pname, age, disease, d2.getName());

        patientCount++;
        cout << "? Patient admitted under " << d2.getName() << endl;
    }
    else {
        cout << "? Invalid doctor choice!\n";
    }
}

void showPatients(Patient &p1, Patient &p2) {
    cout << "\n--- Patients List ---\n";
    if (!p1.isEmpty()) p1.showInfo();
    if (!p2.isEmpty()) p2.showInfo();

    if (p1.isEmpty() && p2.isEmpty())
        cout << "No patients admitted yet.\n";
}

void dischargePatient(Patient &p1, Patient &p2, int &patientCount) {
    if (patientCount == 0) {
        cout << "\nNo patients to discharge.\n";
        return;
    }

    string dischargeName;
    cout << "\nEnter patient name to discharge: ";
    cin >> dischargeName;

    if (!p1.isEmpty() && p1.getName() == dischargeName) {
        p1.clear();
        patientCount--;
        cout << "? Patient discharged successfully!\n";
        return;
    }
    if (!p2.isEmpty() && p2.getName() == dischargeName) {
        p2.clear();
        patientCount--;
        cout << "? Patient discharged successfully!\n";
        return;
    }

    cout << "? No patient found with this name.\n";
}

int main() {
    Doctor d1("Dr. Ali", 45, "Cardiologist");
    Doctor d2("Dr. Sara", 38, "Orthopedic");

    Patient p1, p2;
    int patientCount = 0;
    int option;

    hospitalIntro();

    while (true) {
        cout << "\n====== HOSPITAL MANAGEMENT MENU ======\n";
        cout << "1. Show Doctors\n";
        cout << "2. Admit Patient\n";
        cout << "3. Show Patients\n";
        cout << "4. Discharge Patient\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> option;

        if (option == 1) {
            showDoctors(d1, d2);
        }
        else if (option == 2) {
            admitPatient(p1, p2, patientCount, d1, d2);
        }
        else if (option == 3) {
            showPatients(p1, p2);
        }
        else if (option == 4) {
            dischargePatient(p1, p2, patientCount);
        }
        else if (option == 0) {
            cout << "\nThank you for using City Hospital System!\n";
            break;
        }
        else {
            cout << "? Invalid choice, please try again.\n";
        }
    }

    return 0;
}
